# API PERPUSTAKAAN
**CARA MENJALANKAN API**

- Untuk GET request: http://localhost/api/perpus.php

- Untuk POST request: Gunakan Postman atau alat lainnya untuk mengirim request ke http://localhost/api/perpus.php dengan body JSON seperti:
```
{
    "namabuku": "CARA AGAR RAJIN SHOLAT",
    "penerbit": "M ARIF",
    "tahun": 2099
}
